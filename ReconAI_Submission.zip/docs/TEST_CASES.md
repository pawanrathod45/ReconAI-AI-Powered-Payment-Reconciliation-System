# Test Cases

This document describes the 18 automated test cases in the ReconAI test suite. All tests are located in `backend/tests/test_reconciliation.py` and can be run with:

```bash
cd backend
python -m pytest tests/ -v
```

---

## Test Summary

| Test ID | Description | Input | Expected Result | Status |
|---------|-------------|-------|-----------------|--------|
| TC01 | Exact amount match | TXN ₹1,000.00 with matching STL ₹1,000.00, same reference | MATCHED | ✅ PASS |
| TC02 | 1-day settlement delay | TXN on Oct 15, STL on Oct 16, same amount | MATCHED | ✅ PASS |
| TC03 | 2-day settlement delay | TXN on Oct 14, STL on Oct 16, same amount | MATCHED | ✅ PASS |
| TC04 | Rounding difference (₹0.01) | TXN ₹1,000.00, STL ₹999.99 | ROUNDING_DIFFERENCE | ✅ PASS |
| TC05 | Month-end timing difference | TXN on Oct 31, STL on Nov 1, same amount | TIMING_DIFFERENCE | ✅ PASS |
| TC06 | Missing settlement | TXN exists, no corresponding STL | MISSING_SETTLEMENT | ✅ PASS |
| TC07 | Duplicate settlement | Two STLs with same transaction_ref | First MATCHED, second DUPLICATE | ✅ PASS |
| TC08 | Orphan refund | STL with REF-TXN999, TXN999 does not exist | ORPHAN_REFUND | ✅ PASS |
| TC09 | Unmatched bank settlement | STL references TXN that doesn't exist (non-refund) | UNMATCHED_SETTLEMENT | ✅ PASS |
| TC10 | Multiple exact matches (batch) | 5 TXNs each with matching STLs | All MATCHED | ✅ PASS |
| TC11 | Mixed scenarios | Combination of matched, timing, rounding, missing | Correct classification for each | ✅ PASS |
| TC12 | Case-insensitive matching | TXN with id `txn001`, STL refs `TXN001` | MATCHED (after normalization) | ✅ PASS |
| TC13 | Whitespace in IDs | TXN with id ` TXN001 `, STL refs `TXN001` | MATCHED (after trimming) | ✅ PASS |
| TC14 | Decimal precision | TXN ₹10,000.555, STL ₹10,000.555 | MATCHED (Decimal exact) | ✅ PASS |
| TC15 | Zero-variance match | TXN ₹0.00, STL ₹0.00 | MATCHED | ✅ PASS |
| TC16 | Large amount match | TXN ₹9,99,999.99, STL ₹9,99,999.99 | MATCHED | ✅ PASS |
| TC17 | Summary statistics | Known set of records with predictable counts | Correct summary totals | ✅ PASS |
| TC18 | Reconciliation rate calculation | 8 matched out of 10 total | reconciliation_rate = 80.0% | ✅ PASS |

---

## Detailed Test Descriptions

### TC01 — Exact Amount Match

**Purpose**: Verify the most basic reconciliation scenario — a transaction matched to a settlement with identical reference and amount.

**Input**:
- Transaction: `TXN001`, amount `1000.00`, date `2024-10-15`
- Settlement: `STL001`, transaction_ref `TXN001`, amount `1000.00`, date `2024-10-16`

**Expected**: Status = `MATCHED`, variance = `0.00`

---

### TC02 — 1-Day Settlement Delay

**Purpose**: Confirm that a 1-day delay between transaction and settlement (within the same month) produces a normal match.

**Input**:
- Transaction: `TXN002`, amount `2500.00`, date `2024-10-15`
- Settlement: `STL002`, transaction_ref `TXN002`, amount `2500.00`, date `2024-10-16`

**Expected**: Status = `MATCHED`, variance = `0.00`

---

### TC03 — 2-Day Settlement Delay

**Purpose**: Confirm that a 2-day delay still results in a match.

**Input**:
- Transaction: `TXN003`, amount `7500.00`, date `2024-10-14`
- Settlement: `STL003`, transaction_ref `TXN003`, amount `7500.00`, date `2024-10-16`

**Expected**: Status = `MATCHED`, variance = `0.00`

---

### TC04 — Rounding Difference

**Purpose**: Verify that a ₹0.01 variance is classified as a rounding difference, not a mismatch.

**Input**:
- Transaction: `TXN004`, amount `1000.00`, date `2024-10-15`
- Settlement: `STL004`, transaction_ref `TXN004`, amount `999.99`, date `2024-10-16`

**Expected**: Status = `ROUNDING_DIFFERENCE`, variance = `0.01`

---

### TC05 — Month-End Timing Difference

**Purpose**: Verify that a transaction at month-end settling in the next month is flagged as a timing difference.

**Input**:
- Transaction: `TXN005`, amount `3000.00`, date `2024-10-31`
- Settlement: `STL005`, transaction_ref `TXN005`, amount `3000.00`, date `2024-11-01`

**Expected**: Status = `TIMING_DIFFERENCE`, variance = `0.00`

---

### TC06 — Missing Settlement

**Purpose**: Verify that a transaction with no corresponding settlement is flagged.

**Input**:
- Transaction: `TXN006`, amount `4500.00`, date `2024-10-20`
- No settlement with transaction_ref `TXN006`

**Expected**: Status = `MISSING_SETTLEMENT`

---

### TC07 — Duplicate Settlement

**Purpose**: Verify that when two settlements reference the same transaction, the second is flagged as a duplicate.

**Input**:
- Transaction: `TXN007`, amount `5000.00`, date `2024-10-10`
- Settlement 1: `STL007A`, transaction_ref `TXN007`, amount `5000.00`, date `2024-10-11`
- Settlement 2: `STL007B`, transaction_ref `TXN007`, amount `5000.00`, date `2024-10-11`

**Expected**: First = `MATCHED`, second = `DUPLICATE`

---

### TC08 — Orphan Refund

**Purpose**: Verify that a refund settlement referencing a non-existent transaction is classified as an orphan refund.

**Input**:
- No transaction `TXN999`
- Settlement: `STL008`, transaction_ref `REF-TXN999`, amount `1500.00`, date `2024-10-18`

**Expected**: Status = `ORPHAN_REFUND`

---

### TC09 — Unmatched Bank Settlement

**Purpose**: Verify that a settlement referencing a non-existent transaction (without refund prefix) is flagged.

**Input**:
- No transaction `TXN888`
- Settlement: `STL009`, transaction_ref `TXN888`, amount `2000.00`, date `2024-10-19`

**Expected**: Status = `UNMATCHED_SETTLEMENT`

---

### TC10 — Batch Exact Matches

**Purpose**: Verify correct matching across multiple records simultaneously.

**Input**: 5 transaction-settlement pairs, all with matching references and amounts.

**Expected**: All 5 classified as `MATCHED`

---

### TC11 — Mixed Scenarios

**Purpose**: Verify that the engine correctly classifies a mix of different discrepancy types in a single reconciliation run.

**Input**: Records representing matched, timing difference, rounding difference, and missing settlement scenarios.

**Expected**: Each record classified according to its specific scenario.

---

### TC12 — Case-Insensitive Matching

**Purpose**: Verify that ID normalization handles case differences.

**Input**:
- Transaction: `txn001` (lowercase)
- Settlement: transaction_ref `TXN001` (uppercase)

**Expected**: Status = `MATCHED` after normalization to uppercase.

---

### TC13 — Whitespace in IDs

**Purpose**: Verify that leading/trailing whitespace in IDs is trimmed.

**Input**:
- Transaction: `  TXN001  ` (with spaces)
- Settlement: transaction_ref `TXN001` (clean)

**Expected**: Status = `MATCHED` after trimming.

---

### TC14 — Decimal Precision

**Purpose**: Verify that Decimal arithmetic handles precise values correctly.

**Input**:
- Transaction: `TXN014`, amount `10000.555`
- Settlement: transaction_ref `TXN014`, amount `10000.555`

**Expected**: Status = `MATCHED`, variance = `0.000`

---

### TC15 — Zero-Amount Match

**Purpose**: Verify correct handling of zero-value transactions.

**Input**:
- Transaction: `TXN015`, amount `0.00`
- Settlement: transaction_ref `TXN015`, amount `0.00`

**Expected**: Status = `MATCHED`, variance = `0.00`

---

### TC16 — Large Amount Match

**Purpose**: Verify correct handling of large monetary values.

**Input**:
- Transaction: `TXN016`, amount `999999.99`
- Settlement: transaction_ref `TXN016`, amount `999999.99`

**Expected**: Status = `MATCHED`, variance = `0.00`

---

### TC17 — Summary Statistics

**Purpose**: Verify that the reconciliation summary correctly aggregates counts and totals.

**Input**: A known set of records producing predictable counts for each classification type.

**Expected**: Summary fields (`matched_count`, `unmatched_count`, `timing_differences`, etc.) match expected values.

---

### TC18 — Reconciliation Rate Calculation

**Purpose**: Verify that the reconciliation rate percentage is calculated correctly.

**Input**: 10 total transactions, 8 matched.

**Expected**: `reconciliation_rate` = `80.0` (percentage).

---

## Running Tests

```bash
# Run all tests with verbose output
cd backend
python -m pytest tests/ -v

# Run a specific test
python -m pytest tests/test_reconciliation.py::test_exact_match -v

# Run with coverage report
python -m pytest tests/ -v --cov=app
```
